from setuptools import setup, find_packages


setup(
    name='clean_folder',
    version='0.1',
    description='The code is useful for sorting files in folders',
    long_description=open('README.md').read(),
    url='http://github.com/dummy_user/useful',
    author='Yaroslava Kalat',
    author_email='syayak@gmail.com',
    license='MIT',
    packages=find_packages(),
    entry_points={'console_scripts': ['cleanfolder = clean_folder.clean:path_folder']}#, 'handleknown = clean_folder.clean:handle_known', 'handlearchive = clean_folder.clean:handle_archive', 'main = clean_folder.clean:main', 'handlefolder = clean_folder.clean:handle_folder', 'sorttrash = clean_folder.parser:sort_trash']}
)